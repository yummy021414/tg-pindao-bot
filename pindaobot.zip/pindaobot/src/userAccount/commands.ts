// 用户账号管理命令处理器
import { Context, Markup } from 'telegraf';
import { userAccountDb } from './database';
import { accountController } from './controller';
import { config } from '../config';
import { database } from '../database';

// 检查telegram库是否可用
let telegramAvailable = false;
try {
  require('telegram');
  telegramAvailable = true;
} catch (e) {
  // telegram库未安装
}

export class UserAccountCommands {
  private pendingSessions: Map<number, {
    step: 'waiting_session' | 'waiting_nickname' | 'waiting_api_id' | 'waiting_api_hash';
    session?: string;
    api_id?: string;
    api_hash?: string;
    nickname?: string;
  }> = new Map();

  private pendingMessages: Map<number, {
    step: 'waiting_target' | 'waiting_message';
    target?: string;
  }> = new Map();

  private pendingGroupSend: Map<number, {
    step: 'waiting_keyword' | 'selecting_hours' | 'waiting_group';
    keyword?: string; // 单个关键词（保留兼容性）
    keywords?: string[]; // 多个关键词
    collectedMessages?: any[]; // 收集到的消息
    targetChannel?: string; // 目标频道
    taskId?: string; // 后台任务ID
  }> = new Map();

  private pendingAutoReply: Map<number, {
    step: 'waiting_message';
  }> = new Map();

  // 检查是否是超管
  private isSuperAdmin(userId: number): boolean {
    return userId === config.superAdminId;
  }

  // 主菜单 - 账号管理
  async handleAccountMenu(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) {
      await ctx.reply('⛔ 只有超级管理员可以使用此功能');
      return;
    }

    // 检查telegram库
    if (!telegramAvailable) {
      await ctx.reply(
        '⚠️ 账号控制功能需要安装额外的依赖库\n\n' +
        '请运行以下命令安装：\n' +
        '```\nnpm install telegram input\n```\n\n' +
        '然后重启机器人即可使用。',
        { parse_mode: 'Markdown' }
      );
      return;
    }

    const keyboard = Markup.keyboard([
      ['➕ 添加账号', '📋 账号列表'],
      ['🔄 切换账号', '🗑️ 删除账号'],
      ['💬 发私信', '🤖 自动回复'],
      ['📦 发送媒体库', '📊 账号状态'],
      ['📋 任务状态', '⬅️ 返回主菜单']
    ]).resize();

    await ctx.reply('🎛️ 账号控制面板\n\n请选择功能：', keyboard);
  }

  // 添加账号 - 固定4步流程
  async handleAddAccount(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    this.pendingSessions.set(ctx.from!.id, { step: 'waiting_api_id' });
    
    await ctx.reply(
      '📝 添加新账号\n\n' +
      '请按顺序输入以下信息：\n\n' +
      '第1步：📡 API ID\n' +
      '第2步：🔑 API Hash\n' +
      '第3步：🔐 Session 字符串\n' +
      '第4步：📛 账号昵称\n\n' +
      '━━━━━━━━━━━━━━━━━━━━\n' +
      '💡 API ID 和 Hash 从 https://my.telegram.org 获取\n' +
      '⚠️ Session 包含敏感信息，请确保安全\n\n' +
      '🚀 现在请发送 API ID：'
    );
  }

  // 处理Session输入
  async handleSessionInput(ctx: Context, input: string): Promise<void> {
    const userId = ctx.from!.id;
    const pending = this.pendingSessions.get(userId);

    if (!pending || pending.step !== 'waiting_session') return;

    pending.session = input.trim();
    pending.step = 'waiting_nickname';
    this.pendingSessions.set(userId, pending);

    await ctx.reply(
      '✅ Session已接收\n\n' +
      '📝 第4步：请给这个账号起个昵称（方便识别）：'
    );
  }

  // 处理API ID输入
  async handleApiIdInput(ctx: Context, apiId: string): Promise<void> {
    const userId = ctx.from!.id;
    const pending = this.pendingSessions.get(userId);

    if (!pending || pending.step !== 'waiting_api_id') return;

    pending.api_id = apiId.trim();
    pending.step = 'waiting_api_hash';
    this.pendingSessions.set(userId, pending);

    await ctx.reply('✅ API ID已接收\n\n📝 第2步：请发送 API Hash：');
  }

  // 处理API Hash输入
  async handleApiHashInput(ctx: Context, apiHash: string): Promise<void> {
    const userId = ctx.from!.id;
    const pending = this.pendingSessions.get(userId);

    if (!pending || pending.step !== 'waiting_api_hash') return;

    pending.api_hash = apiHash.trim();
    pending.step = 'waiting_session';
    this.pendingSessions.set(userId, pending);

    await ctx.reply('✅ API Hash已接收\n\n📝 第3步：请发送 Session 字符串：');
  }

  // 处理昵称输入并完成添加
  async handleNicknameInput(ctx: Context, nickname: string): Promise<void> {
    const userId = ctx.from!.id;
    const pending = this.pendingSessions.get(userId);

    if (!pending || pending.step !== 'waiting_nickname') return;

    pending.nickname = nickname.trim();
    await this.finishAddAccount(ctx, pending);
  }

  // 完成添加账号（统一处理）
  private async finishAddAccount(ctx: Context, pending: any): Promise<void> {
    const userId = ctx.from!.id;

    try {
      // 验证必要字段
      if (!pending.session || !pending.api_id || !pending.api_hash || !pending.nickname) {
        await ctx.reply('❌ 信息不完整！请重新添加账号');
        this.pendingSessions.delete(userId);
        return;
      }

      // 保存账号到数据库
      const accountId = await userAccountDb.addAccount({
        phone: '', // 手机号可以后续从session中获取
        session: pending.session,
        api_id: pending.api_id,
        api_hash: pending.api_hash,
        nickname: pending.nickname,
        is_active: false,
      });

      // 尝试登录
      await ctx.reply('🔄 正在验证Session并登录账号...\n\n这可能需要几秒钟时间，请稍候...');
      
      const result = await accountController.loginWithSession(
        accountId,
        pending.api_id,
        pending.api_hash,
        pending.session
      );

      if (result.success) {
        // 使用Python验证返回的用户信息，如果没有则从客户端获取
        const userInfo = result.userInfo || await accountController.getAccountInfo(accountId);
        
        // 更新账号的手机号（如果Python验证成功返回了）
        if (userInfo?.phone) {
          await userAccountDb.updateAccountPhone(accountId, userInfo.phone);
        }
        
        // ✅ 重要：自动激活新添加的账号
        await userAccountDb.setActiveAccount(accountId);
        console.log(`✅ 账号 ${accountId} 已自动激活`);
        
        await ctx.reply(
          `✅ 账号添加成功并已激活！\n\n` +
          `📝 昵称: ${pending.nickname}\n` +
          `🆔 ID: ${accountId}\n` +
          `👤 用户名: ${userInfo?.username || '未设置'}\n` +
          `📱 手机: ${userInfo?.phone || '未知'}\n` +
          `🟢 状态: 已激活（当前使用中）\n\n` +
          `💡 现在可以使用发私信、发送媒体库等功能了！`
        );
      } else {
        await ctx.reply(
          `⚠️ 账号已保存，但登录失败\n\n` +
          `错误信息：${result.error || '未知错误'}\n\n` +
          `可能原因：\n` +
          `1. Session已过期或无效\n` +
          `2. API ID/Hash不正确\n` +
          `3. 网络连接问题\n` +
          `4. 账号被封禁\n\n` +
          `💡 建议：\n` +
          `• 检查Session是否最新\n` +
          `• 确认API ID/Hash正确（从 https://my.telegram.org 获取）\n` +
          `• 检查网络连接\n` +
          `• 可以稍后使用 /账号列表 重新激活账号`
        );
      }

      this.pendingSessions.delete(userId);
    } catch (error: any) {
      const errorMsg = error?.message || String(error);
      await ctx.reply(
        `❌ 添加账号失败\n\n` +
        `错误：${errorMsg}\n\n` +
        `请检查信息后重试`
      );
      this.pendingSessions.delete(userId);
    }
  }

  // 查看账号列表
  async handleAccountList(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const accounts = await userAccountDb.getAllAccounts();

    if (accounts.length === 0) {
      await ctx.reply('📭 还没有添加任何账号\n\n使用 ➕添加账号 来添加第一个账号');
      return;
    }

    let message = '📋 账号列表\n\n';
    
    for (const account of accounts) {
      const status = account.is_active ? '✅ 当前激活' : '⭕';
      message += `${status} ${account.nickname}\n`;
      message += `   🆔 ID: ${account.id}\n`;
      message += `   📅 添加时间: ${new Date(account.created_at).toLocaleString('zh-CN')}\n`;
      if (account.last_used_at) {
        message += `   🕐 最后使用: ${new Date(account.last_used_at).toLocaleString('zh-CN')}\n`;
      }
      message += '\n';
    }

    await ctx.reply(message);
  }

  // 切换账号
  async handleSwitchAccount(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const accounts = await userAccountDb.getAllAccounts();

    if (accounts.length === 0) {
      await ctx.reply('📭 还没有添加任何账号');
      return;
    }

    const buttons = accounts.map(acc => [
      Markup.button.callback(
        `${acc.is_active ? '✅' : '⭕'} ${acc.nickname}`,
        `switch_account_${acc.id}`
      )
    ]);

    await ctx.reply(
      '🔄 选择要激活的账号：',
      Markup.inlineKeyboard(buttons)
    );
  }

  // 处理切换账号回调
  async handleSwitchAccountCallback(ctx: Context, accountId: number): Promise<void> {
    try {
      await ctx.answerCbQuery('🔄 正在切换账号...');
      
      const success = await accountController.activateAccount(accountId);
      
      if (success) {
        const account = await userAccountDb.getAccount(accountId);
        await ctx.reply(
          `✅ 已切换到账号: ${account?.nickname}\n\n` +
          `🆔 账号ID: ${account?.id}\n` +
          `📱 手机: ${account?.phone || '未知'}\n\n` +
          `💡 如果该账号配置了自动回复，已自动启用`
        );
      } else {
        await ctx.reply('❌ 切换账号失败，请检查账号状态或重新添加账号');
      }
    } catch (error: any) {
      await ctx.reply(`❌ 切换失败: ${error?.message || error}`);
    }
  }

  // 删除账号
  async handleDeleteAccount(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const accounts = await userAccountDb.getAllAccounts();

    if (accounts.length === 0) {
      await ctx.reply('📭 还没有添加任何账号');
      return;
    }

    const buttons = accounts.map(acc => [
      Markup.button.callback(
        `${acc.is_active ? '🟢' : '⭕'} ${acc.nickname} (ID: ${acc.id})`,
        `delete_account_${acc.id}`
      )
    ]);

    await ctx.reply(
      '🗑️ 选择要删除的账号：\n\n⚠️ 删除后无法恢复！',
      Markup.inlineKeyboard(buttons)
    );
  }

  // 处理删除账号回调
  async handleDeleteAccountCallback(ctx: Context, accountId: number): Promise<void> {
    try {
      const account = await userAccountDb.getAccount(accountId);
      if (!account) {
        await ctx.answerCbQuery('❌ 账号不存在');
        return;
      }

      // 确认删除
      const confirmButtons = Markup.inlineKeyboard([
        [
          Markup.button.callback('✅ 确认删除', `confirm_delete_${accountId}`),
          Markup.button.callback('❌ 取消', 'cancel_delete')
        ]
      ]);

      await ctx.answerCbQuery();
      await ctx.reply(
        `⚠️ 确认删除账号？\n\n` +
        `📝 昵称: ${account.nickname}\n` +
        `🆔 ID: ${account.id}\n` +
        `📱 手机: ${account.phone || '未知'}\n` +
        `🟢 状态: ${account.is_active ? '激活中' : '未激活'}\n\n` +
        `⚠️ 此操作无法撤销！`,
        confirmButtons
      );
    } catch (error: any) {
      await ctx.answerCbQuery('❌ 操作失败');
      await ctx.reply(`❌ 错误: ${error?.message || error}`);
    }
  }

  // 确认删除账号
  async handleConfirmDelete(ctx: Context, accountId: number): Promise<void> {
    try {
      await ctx.answerCbQuery('🗑️ 正在删除...');
      
      const success = await accountController.deleteAccount(accountId);
      
      if (success) {
        await ctx.reply(
          `✅ 账号已删除\n\n` +
          `💡 如果这是唯一的账号，建议添加新账号\n` +
          `💡 如果还有其他账号，请切换到其他账号`
        );
        
        // 显示剩余账号列表
        const remainingAccounts = await userAccountDb.getAllAccounts();
        if (remainingAccounts.length > 0) {
          await this.handleAccountList(ctx);
        }
      } else {
        await ctx.reply('❌ 删除失败，请稍后重试');
      }
    } catch (error: any) {
      await ctx.reply(`❌ 删除失败: ${error?.message || error}`);
    }
  }

  // 取消删除
  async handleCancelDelete(ctx: Context): Promise<void> {
    await ctx.answerCbQuery('已取消');
    await ctx.reply('✅ 已取消删除操作');
  }

  // 发私信 - 步骤1：输入目标
  async handleSendPrivateMessage(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const activeAccount = await userAccountDb.getActiveAccount();
    if (!activeAccount) {
      await ctx.reply('⚠️ 请先激活一个账号');
      return;
    }

    this.pendingMessages.set(ctx.from!.id, { step: 'waiting_target' });
    
    await ctx.reply(
      `📝 请输入目标用户名或ID\n\n` +
      `例如：\n` +
      `@username\n` +
      `username\n` +
      `123456789`
    );
  }

  // 处理目标输入
  async handleTargetInput(ctx: Context, target: string): Promise<void> {
    const userId = ctx.from!.id;
    const pending = this.pendingMessages.get(userId);

    if (!pending || pending.step !== 'waiting_target') return;

    pending.target = target.trim();
    pending.step = 'waiting_message';
    this.pendingMessages.set(userId, pending);

    await ctx.reply('✅ 目标已设置\n\n📝 请输入要发送的消息内容：');
  }

  // 处理消息内容并发送
  async handleMessageContent(ctx: Context, message: string): Promise<void> {
    const userId = ctx.from!.id;
    const pending = this.pendingMessages.get(userId);

    if (!pending || pending.step !== 'waiting_message') {
      console.log(`[handleMessageContent] 跳过：pending=${!!pending}, step=${pending?.step}`);
      return;
    }

    try {
      console.log(`[handleMessageContent] 开始发送消息：target=${pending.target}, userId=${userId}`);
      await ctx.reply('📤 正在发送消息...');
      
      const success = await accountController.sendPrivateMessage(
        pending.target!,
        message
      );

      if (success) {
        await ctx.reply('✅ 消息发送成功！');
      } else {
        await ctx.reply('❌ 消息发送失败，请检查目标用户名是否正确');
      }

      this.pendingMessages.delete(userId);
    } catch (error) {
      console.error(`[handleMessageContent] 发送失败:`, error);
      await ctx.reply(`❌ 发送失败: ${error}`);
      this.pendingMessages.delete(userId);
    }
  }

  // 设置自动回复
  async handleSetAutoReply(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const activeAccount = await userAccountDb.getActiveAccount();
    if (!activeAccount) {
      await ctx.reply('⚠️ 请先激活一个账号');
      return;
    }

    const config = await userAccountDb.getAutoReply(activeAccount.id);
    const currentStatus = config?.is_enabled ? '已启用' : '未启用';
    const currentMessage = config?.reply_message || '未设置';

    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('📝 设置回复内容', 'set_auto_reply_msg')],
      [
        Markup.button.callback('✅ 启用', 'enable_auto_reply'),
        Markup.button.callback('❌ 禁用', 'disable_auto_reply')
      ]
    ]);

    await ctx.reply(
      `🤖 自动回复设置\n\n` +
      `📊 当前状态: ${currentStatus}\n` +
      `💬 回复内容: ${currentMessage}\n\n` +
      `请选择操作：`,
      keyboard
    );
  }

  // 处理设置自动回复内容（开始等待输入）
  async handleSetAutoReplyMessage(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const activeAccount = await userAccountDb.getActiveAccount();
    if (!activeAccount) {
      await ctx.reply('⚠️ 请先激活一个账号');
      return;
    }

    // 设置等待状态
    this.pendingAutoReply.set(ctx.from!.id, { step: 'waiting_message' });

    await ctx.reply('📝 请输入自动回复的内容：\n\n例如：本号不回复，请联系 @admin');
  }

  // 处理自动回复内容输入
  async handleAutoReplyMessageInput(ctx: Context, message: string): Promise<void> {
    const userId = ctx.from!.id;
    const pending = this.pendingAutoReply.get(userId);

    if (!pending || pending.step !== 'waiting_message') return;

    try {
      const activeAccount = await userAccountDb.getActiveAccount();
      if (!activeAccount) {
        await ctx.reply('⚠️ 请先激活一个账号');
        this.pendingAutoReply.delete(userId);
        return;
      }

      // 保存自动回复配置（默认不启用，需要用户手动启用）
      await userAccountDb.setAutoReply(activeAccount.id, message.trim(), false);
      
      await ctx.reply(
        `✅ 自动回复内容已设置！\n\n` +
        `💬 回复内容: ${message.trim()}\n\n` +
        `💡 提示：请在自动回复设置中点击"✅ 启用"来启用自动回复功能`
      );

      this.pendingAutoReply.delete(userId);
    } catch (error) {
      await ctx.reply(`❌ 设置失败: ${error}`);
      this.pendingAutoReply.delete(userId);
    }
  }

  // 启用自动回复
  async handleEnableAutoReply(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const activeAccount = await userAccountDb.getActiveAccount();
    if (!activeAccount) {
      await ctx.reply('⚠️ 请先激活一个账号');
      return;
    }

    const config = await userAccountDb.getAutoReply(activeAccount.id);
    if (!config || !config.reply_message) {
      await ctx.reply('⚠️ 请先设置回复内容');
      return;
    }

    await userAccountDb.toggleAutoReply(activeAccount.id, true);
    await accountController.enableAutoReply(activeAccount.id);
    
    await ctx.reply('✅ 自动回复已启用');
  }

  // 禁用自动回复
  async handleDisableAutoReply(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const activeAccount = await userAccountDb.getActiveAccount();
    if (!activeAccount) {
      await ctx.reply('⚠️ 请先激活一个账号');
      return;
    }

    await userAccountDb.toggleAutoReply(activeAccount.id, false);
    await accountController.disableAutoReply(activeAccount.id); // 移除监听器
    
    await ctx.reply('❌ 自动回复已禁用');
  }

  // 发送媒体库 - 步骤1：选择关键词
  async handleSendMediaLibrary(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const activeAccount = await userAccountDb.getActiveAccount();
    if (!activeAccount) {
      await ctx.reply('⚠️ 请先激活一个账号');
      return;
    }

    const keywords = await database.getAllKeywords();
    
    if (keywords.length === 0) {
      await ctx.reply('📭 媒体库中还没有任何关键词');
      return;
    }

    this.pendingGroupSend.set(ctx.from!.id, { step: 'waiting_keyword' });

    await ctx.reply(
      `📦 媒体库发送\n\n` +
      `📝 请输入要发送的关键词（支持多种格式）：\n\n` +
      `💡 格式示例：\n` +
      `• 每行一个：\n` +
      `  123\n` +
      `  456\n` +
      `  789\n\n` +
      `• 逗号分隔：123, 456, 789\n` +
      `• 空格分隔：123 456 789\n\n` +
      `可用关键词：\n${keywords.join(', ')}`
    );
  }

  // 处理关键词输入（支持多行，每行一个关键词）
  async handleKeywordInput(ctx: Context, keywordsText: string): Promise<void> {
    const userId = ctx.from!.id;
    const pending = this.pendingGroupSend.get(userId);

    if (!pending || pending.step !== 'waiting_keyword') return;

    // 解析关键词（支持多种格式：每行一个、空格分隔、逗号分隔）
    let keywordLines: string[] = [];
    
    // 先按换行符分割
    const lines = keywordsText.split('\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      
      // 检查是否包含逗号或空格（可能是多个关键词）
      if (trimmed.includes(',') || trimmed.includes('，')) {
        // 逗号分隔
        const keywords = trimmed.split(/[,，]/).map(k => k.trim()).filter(k => k.length > 0);
        keywordLines.push(...keywords);
      } else if (trimmed.includes(' ')) {
        // 空格分隔
        const keywords = trimmed.split(/\s+/).map(k => k.trim()).filter(k => k.length > 0);
        keywordLines.push(...keywords);
      } else {
        // 单行单个关键词
        keywordLines.push(trimmed);
      }
    }

    // 清理关键词：移除@符号（如果用户误输入了@）
    keywordLines = keywordLines.map(k => k.replace(/^@+/, '').trim()).filter(k => k.length > 0);

    if (keywordLines.length === 0) {
      await ctx.reply('❌ 请输入至少一个关键词（支持多种格式：每行一个、空格分隔、逗号分隔）');
      return;
    }

    // 去重
    keywordLines = [...new Set(keywordLines)];

    console.log(`[关键词识别] 解析出 ${keywordLines.length} 个关键词:`, keywordLines);

    // 验证所有关键词
    const validKeywords: string[] = [];
    const invalidKeywords: string[] = [];
    
    for (const keyword of keywordLines) {
      const exists = await database.keywordExists(keyword);
      if (exists) {
        validKeywords.push(keyword);
      } else {
        invalidKeywords.push(keyword);
      }
    }

    if (validKeywords.length === 0) {
      await ctx.reply('❌ 所有关键词都不存在，请重新输入');
      return;
    }

    // 显示验证结果
    let replyMessage = `✅ 已识别 ${validKeywords.length} 个有效关键词：\n\n`;
    for (let index = 0; index < validKeywords.length; index++) {
      const kw = validKeywords[index];
      const count = (await database.getMediaByKeyword(kw)).length;
      replyMessage += `${index + 1}. "${kw}" - ${count} 个媒体\n`;
    }

    if (invalidKeywords.length > 0) {
      replyMessage += `\n⚠️ 无效关键词（已忽略）：${invalidKeywords.join(', ')}\n`;
    }

    replyMessage += `\n🔄 正在搜索并收集资料，请稍候...`;

    await ctx.reply(replyMessage);

    // 保存关键词，直接进入后台任务模式
    pending.keywords = validKeywords;
    pending.keyword = validKeywords[0]; // 保留兼容性
    pending.step = 'waiting_group';
    this.pendingGroupSend.set(userId, pending);

    await ctx.reply(
      `✅ 已识别 ${validKeywords.length} 个有效关键词\n` +
      `📊 预计消息数: ${validKeywords.length * 10} 条左右\n` +
      `⏰ 预计收集时间: ${Math.ceil(validKeywords.length * 15 / 60)} 分钟\n\n` +
      `📝 请输入目标群组或频道用户名/ID：\n\n` +
      `例如：@groupname 或 -1001234567890\n\n` +
      `💡 下一步将选择发送时间分布（1-24小时）`
    )
  }

  // 注：已删除模式选择功能，统一使用后台任务模式

  // 处理时间选择回调
  async handleHoursCallback(ctx: Context, hours: number): Promise<void> {
    const userId = ctx.from!.id;
    const pending = this.pendingGroupSend.get(userId);

    if (!pending || pending.step !== 'selecting_hours') return;

    try {
      await ctx.answerCbQuery();

      await ctx.reply(
        `⏰ 已选择：${hours}小时内完成\n\n` +
        `🚀 正在启动后台任务...\n` +
        `💡 这可能需要几秒钟`
      );

      // 启动后台任务
      const result = await accountController.startBackgroundCollectionTask(
        userId,
        pending.keywords!,
        pending.targetChannel!,
        {
          spreadHours: hours,
          startDelay: 0.1, // 6分钟后开始发送
        },
        async (taskResult: any) => {
          // 完成回调
          if (taskResult.success) {
            await ctx.reply(
              `🎉 任务收集完成！\n\n` +
              `📊 共收集 ${taskResult.messageCount} 条消息\n` +
              `📅 已设置定时发送\n` +
              `⏰ 发送时间: ${taskResult.scheduleResult.startTime.toLocaleString('zh-CN')} ~ ${taskResult.scheduleResult.endTime.toLocaleString('zh-CN')}\n\n` +
              `💡 消息将自动发送，保证顺序和完整性！\n` +
              `💡 您现在可以继续使用其他功能了！`
            );
          } else {
            await ctx.reply(`❌ 任务失败: ${taskResult.error}`);
          }

          this.pendingGroupSend.delete(userId);
        }
      );

      await ctx.reply(result.message);
      this.pendingGroupSend.delete(userId);

    } catch (error: any) {
      await ctx.reply(`❌ 启动任务失败: ${error?.message || error}`);
      this.pendingGroupSend.delete(userId);
    }
  }

  // 处理群组输入并发送
  async handleGroupInput(ctx: Context, group: string): Promise<void> {
    const userId = ctx.from!.id;
    const pending = this.pendingGroupSend.get(userId);

    if (!pending || pending.step !== 'waiting_group') return;

    try {
      // 保存目标群组
      pending.targetChannel = group;

      // 统一使用后台任务模式，询问时间分布
      pending.step = 'selecting_hours';
      this.pendingGroupSend.set(userId, pending);

      const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('1小时内完成', 'send_hours_1')],
        [Markup.button.callback('6小时内完成', 'send_hours_6')],
        [Markup.button.callback('12小时内完成', 'send_hours_12')],
        [Markup.button.callback('24小时内完成 (推荐)', 'send_hours_24')],
      ]);

      await ctx.reply(
        `✅ 目标已设置：${group}\n\n` +
        `⏰ 请选择发送时间分布：\n\n` +
        `💡 时间越长，发送越稳定，顺序越不容易乱\n` +
        `💡 收集期间您可以继续使用其他功能`,
        keyboard
      );
    } catch (error: any) {
      await ctx.reply(`❌ 操作失败: ${error?.message || error}`);
      this.pendingGroupSend.delete(userId);
    }
  }

  // 获取账号状态
  async handleAccountStatus(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const activeAccount = await userAccountDb.getActiveAccount();
    
    if (!activeAccount) {
      await ctx.reply('⚠️ 当前没有激活的账号');
      return;
    }

    const info = await accountController.getAccountInfo(activeAccount.id);
    const autoReply = await userAccountDb.getAutoReply(activeAccount.id);

    let message = `📊 当前账号状态\n\n`;
    message += `📝 昵称: ${activeAccount.nickname}\n`;
    message += `🆔 账号ID: ${activeAccount.id}\n`;
    
    if (info) {
      message += `👤 用户名: @${info.username || '未设置'}\n`;
      message += `📱 手机: ${info.phone || '未知'}\n`;
      message += `🏷️ 姓名: ${info.firstName || ''} ${info.lastName || ''}\n`;
    }
    
    message += `\n🤖 自动回复: ${autoReply?.is_enabled ? '✅ 已启用' : '❌ 未启用'}\n`;
    
    if (autoReply?.is_enabled) {
      message += `💬 回复内容: ${autoReply.reply_message}\n`;
    }

    await ctx.reply(message);
  }

  // 查询任务状态
  async handleTaskStatus(ctx: Context): Promise<void> {
    if (!this.isSuperAdmin(ctx.from?.id!)) return;

    const runningTasks = accountController.getRunningTasks();

    if (runningTasks.length === 0) {
      await ctx.reply('📭 当前没有运行中的后台任务\n\n💡 后台任务在收集完成并设置定时发送后会显示为"发送中"状态');
      return;
    }

    let message = `📋 后台任务列表\n\n`;
    
    for (const task of runningTasks) {
      const status = accountController.getTaskStatus(task.taskId);
      if (status) {
        message += `🆔 任务ID: ${task.taskId.substring(5, 20)}...\n`;
        message += `${status.statusText}\n`;
        
        if (status.status === 'collecting') {
          message += `📊 收集进度: ${status.progress}\n`;
          message += `📦 已收集: ${status.collectedCount} 条\n`;
          message += `⏱️ 已用时: ${status.elapsed}\n`;
        } else if (status.status === 'scheduling') {
          message += `📅 正在设置定时发送...\n`;
          message += `📦 已收集: ${status.collectedCount} 条\n`;
        } else if (status.status === 'sending') {
          message += `📤 定时器运行中\n`;
          message += `📦 消息总数: ${status.collectedCount} 条\n`;
          message += `📊 发送进度: ${status.scheduledGroups || 0}/${status.totalGroups || 0} 组\n`;
          message += `⏱️ 运行时间: ${status.elapsed}\n`;
          message += `💡 请保持机器人运行直到发送完成\n`;
        }
        
        message += `\n`;
      }
    }

    await ctx.reply(message);
  }

  // 取消当前操作
  async handleCancel(ctx: Context): Promise<void> {
    const userId = ctx.from!.id;
    
    // 清除所有待处理状态
    const hadPending = 
      this.pendingSessions.has(userId) ||
      this.pendingMessages.has(userId) ||
      this.pendingGroupSend.has(userId) ||
      this.pendingAutoReply.has(userId);
    
    this.pendingSessions.delete(userId);
    this.pendingMessages.delete(userId);
    this.pendingGroupSend.delete(userId);
    this.pendingAutoReply.delete(userId);
    
    if (hadPending) {
      await ctx.reply('✅ 当前操作已取消\n\n返回账号控制面板');
      await this.handleAccountMenu(ctx);
    } else {
      await ctx.reply('💡 当前没有进行中的操作');
    }
  }

  // 统一的消息处理入口
  // 返回true表示已处理该消息，false表示未处理（让其他处理器继续处理）
  async handleTextMessage(ctx: Context): Promise<boolean> {
    const userId = ctx.from!.id;
    const text = (ctx.message as any).text;

    if (!text) return false;

    // 检查是否是取消命令
    if (text === '/cancel' || text === '取消' || text === '❌ 取消') {
      await this.handleCancel(ctx);
      return true;
    }

    // 检查是否在等待Session输入
    const sessionPending = this.pendingSessions.get(userId);
    if (sessionPending) {
      console.log(`[handleTextMessage] 处理Session输入：userId=${userId}, step=${sessionPending.step}`);
      switch (sessionPending.step) {
        case 'waiting_session':
          await this.handleSessionInput(ctx, text);
          return true; // 已处理
        case 'waiting_api_id':
          await this.handleApiIdInput(ctx, text);
          return true; // 已处理
        case 'waiting_api_hash':
          await this.handleApiHashInput(ctx, text);
          return true; // 已处理
        case 'waiting_nickname':
          await this.handleNicknameInput(ctx, text);
          return true; // 已处理
      }
    }

    // 检查是否在等待发私信
    const messagePending = this.pendingMessages.get(userId);
    if (messagePending) {
      console.log(`[handleTextMessage] 处理私信输入：userId=${userId}, step=${messagePending.step}, target=${messagePending.target}`);
      switch (messagePending.step) {
        case 'waiting_target':
          await this.handleTargetInput(ctx, text);
          return true; // 已处理
        case 'waiting_message':
          await this.handleMessageContent(ctx, text);
          return true; // 已处理
      }
    }

    // 检查是否在等待发送媒体库
    const groupPending = this.pendingGroupSend.get(userId);
    if (groupPending) {
      switch (groupPending.step) {
        case 'waiting_keyword':
          await this.handleKeywordInput(ctx, text);
          return true; // 已处理
        case 'selecting_hours':
          // 等待时间选择，不接受文本输入
          await ctx.reply('💡 请点击上方按钮选择时间');
          return true; // 已处理
        case 'waiting_group':
          await this.handleGroupInput(ctx, text);
          return true; // 已处理
      }
    }

    // 检查是否在等待自动回复内容输入
    const autoReplyPending = this.pendingAutoReply.get(userId);
    if (autoReplyPending) {
      switch (autoReplyPending.step) {
        case 'waiting_message':
          await this.handleAutoReplyMessageInput(ctx, text);
          return true; // 已处理
      }
    }

    // 没有匹配的待处理状态，返回false让其他处理器继续
    return false;
  }
}

export const userAccountCommands = new UserAccountCommands();

