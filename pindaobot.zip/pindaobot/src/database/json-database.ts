import { MediaItem, UserPermission, PermissionType } from '../types';
import { config } from '../config';
import * as fs from 'fs';
import * as path from 'path';

interface UserInfo {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
  last_active: string;
}

interface DatabaseData {
  media: MediaItem[];
  userPermissions: UserPermission[];
  userSessions: { [userId: number]: any };
  users: UserInfo[]; // 新增：用户信息
}

export class JsonDatabase {
  private dataPath: string;
  private data: DatabaseData = {
    media: [],
    userPermissions: [],
    userSessions: {},
    users: [] // 新增
  };

  constructor() {
    // 使用 path.join 和 __dirname 确保数据库路径是相对于项目根目录的绝对路径
    const projectRoot = path.join(__dirname, '..', '..');
    // 如果是绝对路径，直接使用；否则拼接到项目根目录
    if (config.databasePath.startsWith('/')) {
      this.dataPath = config.databasePath.replace('.db', '.json');
    } else {
      this.dataPath = path.join(projectRoot, config.databasePath.replace('.db', '.json'));
    }

    // 确保数据目录存在
    const dataDir = path.dirname(this.dataPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    console.log(`🗄️ JSON数据库路径: ${this.dataPath}`);
    
    this.loadData();
  }

  private loadData(): void {
    try {
      if (fs.existsSync(this.dataPath)) {
        const fileContent = fs.readFileSync(this.dataPath, 'utf8');
        const loadedData = JSON.parse(fileContent);
        
        // 兼容旧数据：如果没有users字段，初始化为空数组
        this.data = {
          media: loadedData.media || [],
          userPermissions: loadedData.userPermissions || [],
          userSessions: loadedData.userSessions || {},
          users: loadedData.users || [] // 兼容旧数据
        };
        
        console.log('✅ JSON数据库加载成功');
        console.log(`📊 用户数: ${this.data.users.length}, 媒体数: ${this.data.media.length}`);
      } else {
        this.data = {
          media: [],
          userPermissions: [],
          userSessions: {},
          users: []
        };
        this.saveData();
        console.log('✅ 创建新的JSON数据库');
      }
    } catch (error) {
      console.error('❌ JSON数据库加载失败:', error);
      this.data = {
        media: [],
        userPermissions: [],
        userSessions: {},
        users: []
      };
    }
  }

  private saveData(): void {
    try {
      fs.writeFileSync(this.dataPath, JSON.stringify(this.data, null, 2));
    } catch (error) {
      console.error('❌ JSON数据库保存失败:', error);
    }
  }

  // 媒体相关方法
  async saveMedia(mediaItem: Omit<MediaItem, 'id'>): Promise<number> {
    const newId = this.data.media.length > 0 ? Math.max(...this.data.media.map(m => m.id)) + 1 : 1;
    const item: MediaItem = {
      ...mediaItem,
      id: newId
    };
    this.data.media.push(item);
    this.saveData();
    return newId;
  }

  async getMediaByKeyword(keyword: string, userId?: number): Promise<MediaItem[]> {
    let results = this.data.media.filter(item => item.keyword === keyword);
    
    if (userId !== undefined) {
      results = results.filter(item => item.uploaded_by === userId);
    }
    
    return results;
  }

  async searchMedia(keyword: string, userId?: number, limit: number = 10): Promise<MediaItem[]> {
    let results = this.data.media.filter(item => 
      item.keyword === keyword
    );
    
    if (userId !== undefined) {
      results = results.filter(item => item.uploaded_by === userId);
    }
    
    return results.slice(0, limit);
  }

  async updateMediaPublished(id: number, channelId: string): Promise<void> {
    const item = this.data.media.find(m => m.id === id);
    if (item) {
      item.is_published = true;
      item.channel_id = channelId;
      this.saveData();
    }
  }

  async getMediaStats(): Promise<any> {
    const totalMedia = this.data.media.length;
    const publishedMedia = this.data.media.filter(m => m.is_published).length;
    const uniqueKeywords = new Set(this.data.media.map(m => m.keyword)).size;
    
    return {
      totalMedia,
      publishedMedia,
      uniqueKeywords,
      unpublishedMedia: totalMedia - publishedMedia
    };
  }

  async getAllKeywords(userId?: number): Promise<string[]> {
    let media = this.data.media;
    
    if (userId !== undefined) {
      media = media.filter(item => item.uploaded_by === userId);
    }
    
    // 按关键词的最新上传时间排序（新到旧）
    const keywordMap = new Map<string, string>();
    
    media.forEach(item => {
      const existingTime = keywordMap.get(item.keyword);
      if (!existingTime || item.uploaded_at > existingTime) {
        keywordMap.set(item.keyword, item.uploaded_at);
      }
    });
    
    // 按时间排序（新到旧）
    const sortedKeywords = Array.from(keywordMap.entries())
      .sort(([, timeA], [, timeB]) => timeB.localeCompare(timeA))
      .map(([keyword]) => keyword);
    
    return sortedKeywords;
  }

  async keywordExists(keyword: string, userId?: number): Promise<boolean> {
    let media = this.data.media;
    
    if (userId !== undefined) {
      media = media.filter(item => item.uploaded_by === userId);
    }
    
    return media.some(item => item.keyword === keyword);
  }

  async deleteKeyword(keyword: string, userId?: number): Promise<number> {
    let deletedCount = 0;
    
    if (userId !== undefined) {
      // 删除特定用户的关键词
      const beforeLength = this.data.media.length;
      this.data.media = this.data.media.filter(item => 
        !(item.keyword === keyword && item.uploaded_by === userId)
      );
      deletedCount = beforeLength - this.data.media.length;
    } else {
      // 删除所有关键词
      const beforeLength = this.data.media.length;
      this.data.media = this.data.media.filter(item => item.keyword !== keyword);
      deletedCount = beforeLength - this.data.media.length;
    }
    
    if (deletedCount > 0) {
      this.saveData();
    }
    
    return deletedCount;
  }

  // 用户权限相关方法
  async checkUserPermission(userId: number): Promise<boolean> {
    return this.data.userPermissions.some(perm => 
      perm.user_id === userId && (perm.type === 'monthly' || perm.type === 'quarterly' || perm.type === 'lifetime')
    );
  }

  async addUserPermission(userId: number, type: PermissionType): Promise<void> {
    const existingIndex = this.data.userPermissions.findIndex(perm => perm.user_id === userId);
    
    if (existingIndex >= 0) {
      this.data.userPermissions[existingIndex].type = type;
    } else {
      this.data.userPermissions.push({
        user_id: userId,
        type,
        granted_at: new Date().toISOString()
      });
    }
    
    this.saveData();
  }

  async removeUserPermission(userId: number): Promise<void> {
    this.data.userPermissions = this.data.userPermissions.filter(perm => perm.user_id !== userId);
    this.saveData();
  }

  async getUserCount(): Promise<number> {
    return this.data.users.length; // 返回所有使用过机器人的用户数
  }

  // 用户会话相关方法
  async saveUserSession(userId: number, session: any): Promise<void> {
    this.data.userSessions[userId] = session;
    this.saveData();
  }

  async getUserSession(userId: number): Promise<any> {
    return this.data.userSessions[userId] || null;
  }

  async deleteUserSession(userId: number): Promise<void> {
    delete this.data.userSessions[userId];
    this.saveData();
  }

  // 清理过期数据
  async cleanExpiredData(): Promise<number> {
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    
    const beforeLength = this.data.media.length;
    this.data.media = this.data.media.filter(item => {
      const uploadDate = new Date(item.uploaded_at);
      return uploadDate > thirtyDaysAgo;
    });
    
    const deletedCount = beforeLength - this.data.media.length;
    if (deletedCount > 0) {
      this.saveData();
    }
    
    return deletedCount;
  }

  // 添加缺失的方法
  async getAllMedia(userId?: number): Promise<MediaItem[]> {
    if (userId) {
      return this.data.media.filter(item => item.uploaded_by === userId);
    }
    return this.data.media;
  }

  async deleteMedia(id: number): Promise<void> {
    this.data.media = this.data.media.filter(item => item.id !== id);
    this.saveData();
  }

  async getMediaCount(userId?: number): Promise<number> {
    if (userId) {
      return this.data.media.filter(item => item.uploaded_by === userId).length;
    }
    return this.data.media.length;
  }

  async cleanInvalidMedia(): Promise<number> {
    // 简单实现：返回0，表示没有清理任何媒体
    return 0;
  }

  async getUserPermissions(userId: number): Promise<UserPermission[]> {
    return this.data.userPermissions.filter(perm => perm.user_id === userId);
  }

  async grantUserPermission(userId: number, type: string): Promise<void> {
    const existing = this.data.userPermissions.find(perm => perm.user_id === userId && perm.type === type);
    if (!existing) {
      this.data.userPermissions.push({
        user_id: userId,
        type: type as PermissionType,
        granted_at: new Date().toISOString()
      });
      this.saveData();
    }
  }

  async revokeUserPermission(userId: number, type: string): Promise<void> {
    this.data.userPermissions = this.data.userPermissions.filter(
      perm => !(perm.user_id === userId && perm.type === type)
    );
    this.saveData();
  }

  async getAllUserPermissions(): Promise<UserPermission[]> {
    return this.data.userPermissions;
  }

  async getExpiringUsers(): Promise<any[]> {
    // 简单实现：返回空数组
    return [];
  }

  async markReminderSent(userId: number): Promise<void> {
    // 简单实现：不做任何操作
  }

  async clearUserSession(userId: number): Promise<void> {
    delete this.data.userSessions[userId];
    this.saveData();
  }

  async trackUser(userId: number, first_name?: string, last_name?: string, username?: string): Promise<void> {
    // 查找或创建用户记录
    let user = this.data.users.find(u => u.id === userId);
    
    if (user) {
      // 更新现有用户
      if (first_name) user.first_name = first_name;
      if (last_name) user.last_name = last_name;
      if (username) user.username = username;
      user.last_active = new Date().toISOString();
    } else {
      // 创建新用户
      user = {
        id: userId,
        first_name: first_name || undefined,
        last_name: last_name || undefined,
        username: username || undefined,
        last_active: new Date().toISOString()
      };
      this.data.users.push(user);
    }
    
    this.saveData();
    console.log(`[用户追踪] 👤 用户 ${userId} (${first_name || username || 'Unknown'}) 已记录`);
  }

  async getChatUsers(): Promise<any[]> {
    // 简单实现：返回空数组
    return [];
  }

  async saveChatMessage(userId: number, messageId: number, content: string): Promise<void> {
    // 简单实现：不做任何操作
  }

  async getAllActiveUsers(): Promise<any[]> {
    // 返回所有使用过机器人的用户
    return this.data.users.map(user => ({
      id: user.id,
      first_name: user.first_name,
      last_name: user.last_name,
      username: user.username,
      last_active: user.last_active
    }));
  }

  async getKeywordCount(): Promise<number> {
    const keywords = new Set(this.data.media.map(item => item.keyword));
    return keywords.size;
  }

  async close(): Promise<void> {
    // 简单实现：不做任何操作
  }

}
