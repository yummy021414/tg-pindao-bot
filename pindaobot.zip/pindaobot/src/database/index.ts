import { MediaItem, UserPermission, UserSession } from '../types';
import { JsonDatabase } from './json-database';

export class Database {
  private jsonDb: JsonDatabase;

  constructor() {
    // 使用 JSON 数据库替代 SQLite
    this.jsonDb = new JsonDatabase();
  }

  // 媒体相关方法
  async saveMedia(media: Omit<MediaItem, 'id'>): Promise<number> {
    return this.jsonDb.saveMedia(media);
  }

  async getMediaByKeyword(keyword: string, userId?: number): Promise<MediaItem[]> {
    return this.jsonDb.getMediaByKeyword(keyword, userId);
  }

  async getAllMedia(userId?: number): Promise<MediaItem[]> {
    return this.jsonDb.getAllMedia(userId);
  }

  async deleteMedia(id: number): Promise<void> {
    return this.jsonDb.deleteMedia(id);
  }

  async updateMediaPublished(id: number, channelId: string): Promise<void> {
    return this.jsonDb.updateMediaPublished(id, channelId);
  }

  async getMediaCount(userId?: number): Promise<number> {
    return this.jsonDb.getMediaCount(userId);
  }

  async cleanInvalidMedia(): Promise<number> {
    return this.jsonDb.cleanInvalidMedia();
  }

  // 用户权限相关方法
  async getUserPermissions(userId: number): Promise<UserPermission[]> {
    return this.jsonDb.getUserPermissions(userId);
  }

  async grantUserPermission(userId: number, type: string): Promise<void> {
    return this.jsonDb.grantUserPermission(userId, type);
  }

  async revokeUserPermission(userId: number, type: string): Promise<void> {
    return this.jsonDb.revokeUserPermission(userId, type);
  }

  async getAllUserPermissions(): Promise<UserPermission[]> {
    return this.jsonDb.getAllUserPermissions();
  }

  async getExpiringUsers(): Promise<any[]> {
    return this.jsonDb.getExpiringUsers();
  }

  async markReminderSent(userId: number): Promise<void> {
    return this.jsonDb.markReminderSent(userId);
  }

  // 用户会话相关方法
  async saveUserSession(userId: number, session: UserSession): Promise<void> {
    return this.jsonDb.saveUserSession(userId, session);
  }

  async getUserSession(userId: number): Promise<UserSession | null> {
    return this.jsonDb.getUserSession(userId);
  }

  async clearUserSession(userId: number): Promise<void> {
    return this.jsonDb.clearUserSession(userId);
  }

  async trackUser(userId: number, first_name?: string, last_name?: string, username?: string): Promise<void> {
    return this.jsonDb.trackUser(userId, first_name, last_name, username);
  }

  async getChatUsers(): Promise<any[]> {
    return this.jsonDb.getChatUsers();
  }

  async saveChatMessage(userId: number, messageId: number, content: string): Promise<void> {
    return this.jsonDb.saveChatMessage(userId, messageId, content);
  }

  async getAllActiveUsers(): Promise<any[]> {
    return this.jsonDb.getAllActiveUsers();
  }

  async getKeywordCount(): Promise<number> {
    return this.jsonDb.getKeywordCount();
  }

  async close(): Promise<void> {
    return this.jsonDb.close();
  }

  // 添加缺失的方法
  async checkUserPermission(userId: number): Promise<boolean> {
    return this.jsonDb.checkUserPermission(userId);
  }

  async searchMedia(keyword: string, userId?: number, limit?: number): Promise<MediaItem[]> {
    return this.jsonDb.searchMedia(keyword, userId, limit);
  }

  async getMediaStats(): Promise<any> {
    return this.jsonDb.getMediaStats();
  }

  async getAllKeywords(userId?: number): Promise<string[]> {
    return this.jsonDb.getAllKeywords(userId);
  }

  async keywordExists(keyword: string, userId?: number): Promise<boolean> {
    return this.jsonDb.keywordExists(keyword, userId);
  }

  async deleteKeyword(keyword: string, userId?: number): Promise<number> {
    return this.jsonDb.deleteKeyword(keyword, userId);
  }

  async getUserCount(): Promise<number> {
    return this.jsonDb.getUserCount();
  }
}

// 创建数据库实例
export const database = new Database();