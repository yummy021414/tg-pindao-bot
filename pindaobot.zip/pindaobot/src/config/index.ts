import dotenv from 'dotenv';
import path from 'path';
import { BotConfig } from '../types';

dotenv.config();

export const config: BotConfig = {
  // 使用环境变量；若未提供，使用你给出的固定配置作为安全回退
  botToken: process.env.BOT_TOKEN || '8110189660:AAGM9AJccZDm2lRnUT0kvLT30B0a8HKli9U',
  superAdminId: parseInt(process.env.SUPER_ADMIN_ID || '710485715'),
  channelIds: (process.env.CHANNEL_IDS || '-1001946547227,-1002107445746')
    .split(',')
    .filter(id => id.trim()),
  databasePath: process.env.DATABASE_PATH || path.resolve(__dirname, '..', '..', 'data', 'bot.db')
};

// 授权用户列表：来自环境变量 AUTHORIZED_USERS（逗号分隔），并且自动包含超级管理员
const envAuthorized = (process.env.AUTHORIZED_USERS || '')
  .split(',')
  .map(id => id.trim())
  .filter(Boolean)
  .map(id => parseInt(id, 10))
  .filter(n => !Number.isNaN(n));

export const authorizedUsers: number[] = Array.from(
  new Set([config.superAdminId, ...envAuthorized])
);

// Telegram 公共 API 凭证（用于用户账号登录）
// 这些是 Telethon/GramJS 官方提供的测试凭证，完全可以使用
export const DEFAULT_API_CREDENTIALS = {
  API_ID: '6',
  API_HASH: 'eb06d4abfb49dc3eeb1aeb98ae0f581e'
};

export const BOT_COMMANDS = {
  START: 'start',
  SEARCH: 'search',
  UPLOAD: 'upload',
  PUBLISH: 'publish',
  HELP: 'help',
  ADMIN: 'admin'
} as const;

export const BUTTONS = {
  // 核心功能键盘按钮 (普通用户可见)
  SEARCH_DATA: '🔍 搜索资料',
  UPLOAD_DATA: '📁 上传资料',
  VIEW_KEYWORDS: '🗂️ 查看关键词',
  CHAT_WITH_ADMIN: '💬 联系管理员',
  HELP: 'ℹ️ 帮助',
  
  // 管理员功能键盘按钮
  PUBLISH_CONTENT: '🚀 发布内容',
  VIEW_DATA: '📄 查看资料',
  CHANNEL_MANAGE: '🏢 频道管理',
  USER_MANAGE: '👥 用户管理',
  PERMISSION_MANAGE: '🔐 权限管理',
  BROADCAST_MESSAGE: '📢 群发消息',
  KEYWORD_OPTIMIZE: '🔧 关键词优化',
  APPROVAL: '📝 申请审批',
  
  // 权限管理按钮
  GRANT_MONTHLY: '📅 授权1个月',
  GRANT_QUARTERLY: '📅 授权3个月',
  REVOKE_PERMISSION: '🚫 撤销权限',
  VIEW_PERMISSIONS: '📋 查看权限',
  
  // 内联按钮
  BACK_TO_MAIN: '⬅️ 返回主菜单',
  CANCEL: '❌ 取消',
  CONFIRM: '✅ 确认',
  SAVE_ONLY: '💾 仅保存',
  SAVE_AND_PUBLISH: '💾📢 保存并发布'
} as const;
