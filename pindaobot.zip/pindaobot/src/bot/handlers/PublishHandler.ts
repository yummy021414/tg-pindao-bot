import { Context, Telegraf } from 'telegraf';
import { database } from '../../database';
import { UserSession } from '../../types';
import { config } from '../../config';

export class PublishHandler {
  static async handleKeywordInput(
    ctx: Context, 
    keyword: string, 
    userSessions: Map<number, UserSession>, 
    db: typeof database, 
    bot: Telegraf
  ): Promise<void> {
    const userId = ctx.from?.id;
    if (!userId) return;

    const session = userSessions.get(userId);
    if (!session || session.mode !== 'publish' || !session.selectedChannel) {
      return;
    }

    try {
      await ctx.reply('🔍 正在搜索并发布...');

      // 搜索关键词相关的媒体（只搜索用户自己的数据）
      const mediaItems = await db.getMediaByKeyword(keyword, userId);
      
      if (mediaItems.length === 0) {
        await ctx.reply(
          `❌ 未找到关键词 "${keyword}" 的相关媒体文件。\n\n` +
          `💡 请确保该关键词的媒体已通过上传模式保存到数据库。\n\n` +
          `🔄 继续输入下一个关键词进行发布：`,
          { 
            reply_markup: { 
              inline_keyboard: [
                [{ text: '❌ 退出发布模式', callback_data: 'cancel' }]
              ] 
            } 
          }
        );
        return;
      }

      // 直接发布到频道
      const publishedCount = await this.publishToChannel(
        bot, 
        session.selectedChannel, 
        mediaItems, 
        keyword
      );

      // 更新数据库中的发布状态
      for (const item of mediaItems) {
        await db.updateMediaPublished(item.id, session.selectedChannel);
      }

      const publishedKeyword = keyword; // 保存当前关键词用于显示
      
      // 重置会话状态，保持在发布模式但清空当前关键词，允许连续发布
      session.currentKeyword = undefined;
      session.step = 'waiting_keyword';
      userSessions.set(userId, session);
      await db.saveUserSession(userId, session);
      
      await ctx.reply(
        `✅ 发布完成！\n\n` +
        `关键词: "${publishedKeyword}"\n` +
        `目标频道: ${await this.getChannelName(bot, session.selectedChannel)}\n` +
        `已发布 ${publishedCount} 个媒体文件\n\n` +
        `🔄 发布模式仍然激活\n` +
        `💡 继续输入下一个关键词进行发布，或点击取消退出发布模式。`,
        { 
          reply_markup: { 
            inline_keyboard: [
              [{ text: '❌ 退出发布模式', callback_data: 'cancel' }],
              [{ text: '🏠 返回主菜单', callback_data: 'back_to_main' }]
            ] 
          } 
        }
      );

    } catch (error) {
      console.error('发布搜索错误:', error);
      await ctx.reply('❌ 搜索时发生错误，请稍后重试。');
    }
  }

  static async handleConfirmPublish(
    ctx: Context, 
    userSessions: Map<number, UserSession>, 
    db: typeof database, 
    bot: Telegraf
  ): Promise<void> {
    const userId = ctx.from?.id;
    if (!userId) return;

    const session = userSessions.get(userId);
    if (!session || session.mode !== 'publish' || !session.selectedChannel || !session.currentKeyword) {
      return;
    }

    try {
      await ctx.reply('📢 正在发布到频道...');

      // 获取媒体文件（只获取用户自己的数据）
      const mediaItems = await db.getMediaByKeyword(session.currentKeyword, userId);
      
      if (mediaItems.length === 0) {
        await ctx.reply('❌ 未找到要发布的媒体文件。');
        return;
      }

      // 发布到频道
      const publishedCount = await this.publishToChannel(
        bot, 
        session.selectedChannel, 
        mediaItems, 
        session.currentKeyword
      );

      // 更新数据库中的发布状态
      for (const item of mediaItems) {
        await db.updateMediaPublished(item.id, session.selectedChannel);
      }

      const publishedKeyword = session.currentKeyword; // 保存当前关键词用于显示
      
      // 重置会话状态，保持在发布模式但清空当前关键词，允许连续发布
      session.currentKeyword = undefined;
      session.step = 'waiting_keyword';
      userSessions.set(userId, session);
      await db.saveUserSession(userId, session);
      
      await ctx.reply(
        `✅ 发布完成！\n\n` +
        `关键词: "${publishedKeyword}"\n` +
        `目标频道: ${await this.getChannelName(bot, session.selectedChannel)}\n` +
        `已发布 ${publishedCount} 个媒体文件\n\n` +
        `🔄 发布模式仍然激活\n` +
        `💡 继续输入下一个关键词进行发布，或点击取消退出发布模式。`,
        { 
          reply_markup: { 
            inline_keyboard: [
              [{ text: '❌ 退出发布模式', callback_data: 'cancel' }],
              [{ text: '🏠 返回主菜单', callback_data: 'back_to_main' }]
            ] 
          } 
        }
      );

    } catch (error) {
      console.error('发布错误:', error);
      await ctx.reply('❌ 发布时发生错误，请稍后重试。');
    }
  }

  private static async publishToChannel(
    bot: Telegraf, 
    channelId: string, 
    mediaItems: any[], 
    keyword: string
  ): Promise<number> {
    let publishedCount = 0;

    try {
      console.log(`📢 开始发布 ${mediaItems.length} 个媒体到频道 ${channelId}`);
      
      // 按类型分组媒体（与上传模式保持一致）
      const groupedMedia = this.groupMediaByType(mediaItems);
      
      // 发送所有媒体（保持原始组合）
      await this.sendMediaGroups(bot, channelId, groupedMedia, mediaItems);
      
      publishedCount = mediaItems.length;
      console.log(`✅ 成功发布 ${publishedCount} 个媒体`);

      return publishedCount;
    } catch (error) {
      console.error('发布到频道错误:', error);
      throw error;
    }
  }

  private static async sendMediaGroups(
    bot: Telegraf, 
    channelId: string, 
    groupedMedia: { [key: string]: any[] }, 
    allMedia: any[]
  ): Promise<void> {
    if (allMedia.length === 0) return;

    // 找到主要文字说明（优先选择有文字的媒体）
    const mainCaptionMedia = allMedia.find(item => item.caption && item.caption.trim().length > 0);
    const mainCaption = mainCaptionMedia ? mainCaptionMedia.caption : '';

    // 按类型发送媒体组
    const photoItems = allMedia.filter(item => item.file_type === 'photo');
    const videoItems = allMedia.filter(item => item.file_type === 'video');
    const documentItems = allMedia.filter(item => item.file_type === 'document');
    const audioItems = allMedia.filter(item => item.file_type === 'audio');
    const voiceItems = allMedia.filter(item => item.file_type === 'voice');

    // 合并可以组合的媒体类型（保持完整性）
    const combinedMedia = [...photoItems, ...videoItems, ...documentItems, ...audioItems];

    if (combinedMedia.length > 0) {
      console.log(`📸 发送媒体组合 - 总数: ${combinedMedia.length}`);
      
      // 根据数量决定策略
      if (combinedMedia.length <= 10) {
        // 10个以内，作为一个完整媒体组发送
        try {
          console.log(`📤 作为单个媒体组发送 (${combinedMedia.length} 个媒体)`);
          
          const mediaGroup = combinedMedia.map((item, index) => ({
            type: item.file_type as any,
            media: item.file_id,
            caption: (index === 0 && mainCaption) ? mainCaption : undefined
          }));

          await bot.telegram.sendMediaGroup(channelId, mediaGroup);
          console.log(`✅ 媒体组发送成功（完整）`);
          
        } catch (error) {
          console.error('发送完整媒体组失败，降级为单个发送:', error);
          // 降级：逐个发送
          for (let i = 0; i < combinedMedia.length; i++) {
            try {
              await this.sendSingleMediaToChannel(bot, channelId, combinedMedia[i]);
              console.log(`✅ 单个媒体 ${i + 1}/${combinedMedia.length} 发送成功`);
              
              // 每个媒体间隔3秒
              if (i < combinedMedia.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 3000));
              }
            } catch (singleError) {
              console.error(`发送单个媒体错误:`, singleError);
            }
          }
        }
      } else {
        // 超过10个，按10个一组切分（Telegram限制）
        console.log(`📦 媒体超过10个，分${Math.ceil(combinedMedia.length / 10)}组发送`);
        
        const chunks = this.chunkArray(combinedMedia, 10);
        for (let i = 0; i < chunks.length; i++) {
          const chunk = chunks[i];
          try {
            console.log(`📤 发送媒体组 ${i + 1}/${chunks.length} (${chunk.length} 个媒体)`);
            
            const mediaGroup = chunk.map((item, index) => ({
              type: item.file_type as any,
              media: item.file_id,
              caption: (i === 0 && index === 0 && mainCaption) ? mainCaption : undefined
            }));

            await bot.telegram.sendMediaGroup(channelId, mediaGroup);
            console.log(`✅ 媒体组 ${i + 1} 发送成功`);
            
            // 组间延迟5秒，确保顺序
            if (i < chunks.length - 1) {
              await new Promise(resolve => setTimeout(resolve, 5000));
            }
          } catch (error) {
            console.error(`发送媒体组 ${i + 1} 错误:`, error);
          }
        }
      }
    }

    // 发送语音消息（不能放在媒体组中）
    for (const item of voiceItems) {
      try {
        await this.sendSingleMediaToChannel(bot, channelId, item);
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        console.error('发送语音消息错误:', error);
      }
    }
  }

  private static async sendSingleMediaToChannel(bot: Telegraf, channelId: string, item: any): Promise<void> {
    const caption = item.caption || '';
    
    switch (item.file_type) {
      case 'photo':
        await bot.telegram.sendPhoto(channelId, item.file_id, { caption });
        break;
      case 'video':
        await bot.telegram.sendVideo(channelId, item.file_id, { caption });
        break;
      case 'document':
        await bot.telegram.sendDocument(channelId, item.file_id, { caption });
        break;
      case 'audio':
        await bot.telegram.sendAudio(channelId, item.file_id, { caption });
        break;
      case 'voice':
        await bot.telegram.sendVoice(channelId, item.file_id, { caption });
        break;
    }
  }

  private static groupMediaByType(mediaItems: any[]): { [key: string]: any[] } {
    const grouped: { [key: string]: any[] } = {};
    
    mediaItems.forEach(item => {
      if (!grouped[item.file_type]) {
        grouped[item.file_type] = [];
      }
      grouped[item.file_type].push(item);
    });
    
    return grouped;
  }

  private static formatMediaTypes(groupedMedia: { [key: string]: any[] }): string {
    let result = '';
    
    Object.entries(groupedMedia).forEach(([type, items]) => {
      const typeEmoji = this.getTypeEmoji(type);
      result += `${typeEmoji} ${type}: ${items.length} 个\n`;
    });
    
    return result;
  }

  private static getTypeEmoji(type: string): string {
    const emojiMap: { [key: string]: string } = {
      'photo': '🖼️',
      'video': '🎥',
      'document': '📄',
      'audio': '🎵',
      'voice': '🎤'
    };
    return emojiMap[type] || '📎';
  }

  private static chunkArray<T>(array: T[], size: number): T[][] {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  private static async getChannelName(bot: Telegraf, channelId: string): Promise<string> {
    try {
      const chat = await bot.telegram.getChat(channelId);
      if ('title' in chat) {
        return chat.title;
      } else if ('first_name' in chat) {
        return chat.first_name + (chat.last_name ? ` ${chat.last_name}` : '');
      }
      return `📢 频道 ${channelId}`;
    } catch (error) {
      console.error(`获取频道名称失败 ${channelId}:`, error);
      return `📢 频道 ${channelId}`;
    }
  }

  private static async getChannelFullName(bot: Telegraf, channelId: string): Promise<string> {
    try {
      const chat = await bot.telegram.getChat(channelId);
      if ('title' in chat) {
        return `${chat.title} - 功能正常`;
      } else if ('first_name' in chat) {
        const name = chat.first_name + (chat.last_name ? ` ${chat.last_name}` : '');
        return `${name} - 功能正常`;
      }
      return `📢 频道 ${channelId}`;
    } catch (error) {
      console.error(`获取频道完整名称失败 ${channelId}:`, error);
      return `📢 频道 ${channelId}`;
    }
  }
}
