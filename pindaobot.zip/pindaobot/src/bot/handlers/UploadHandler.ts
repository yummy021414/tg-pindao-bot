import { Context, Telegraf } from 'telegraf';
import { database } from '../../database';
import { UserSession, MediaItem } from '../../types';
import { config } from '../../config';

export class UploadHandler {
  private static uploadTimeouts: Map<number, NodeJS.Timeout> = new Map();

  static async handleKeywordInput(
    ctx: Context, 
    keyword: string, 
    userSessions: Map<number, UserSession>, 
    db: typeof database
  ): Promise<void> {
    const userId = ctx.from?.id;
    if (!userId) return;

    const session = userSessions.get(userId);
    if (!session || session.mode !== 'upload') return;

    session.currentKeyword = keyword;
    session.step = 'waiting_media';
    session.pendingMedia = [];
    userSessions.set(userId, session);
    await db.saveUserSession(userId, session);

    await ctx.reply(
      `📤 上传模式\n\n` +
      `关键词: "${keyword}"\n\n` +
      `请上传媒体文件（支持图片、视频、文档、音频等）：\n\n` +
      `💡 提示：可以一次上传多个文件，然后选择目标频道。`,
      { reply_markup: { inline_keyboard: [[{ text: '❌ 取消', callback_data: 'cancel' }]] } }
    );
  }

  static async handleMediaMessage(
    ctx: Context, 
    mediaType: string, 
    userSessions: Map<number, UserSession>, 
    db: typeof database
  ): Promise<void> {
    const userId = ctx.from?.id;
    if (!userId) return;

    const session = userSessions.get(userId);
    if (!session || session.mode !== 'upload' || session.step !== 'waiting_media') {
      return;
    }

    if (!session.pendingMedia) {
      session.pendingMedia = [];
    }

    let fileId: string | undefined;
    let caption: string | undefined;

    if (ctx.message) {
      switch (mediaType) {
        case 'photo':
          if ('photo' in ctx.message && ctx.message.photo) {
            const photo = ctx.message.photo;
            if (photo.length > 0) {
              fileId = photo[photo.length - 1].file_id;
              caption = 'caption' in ctx.message ? ctx.message.caption : undefined;
            }
          }
          break;
        case 'video':
          if ('video' in ctx.message && ctx.message.video) {
            const video = ctx.message.video;
            fileId = video.file_id;
            caption = 'caption' in ctx.message ? ctx.message.caption : undefined;
          }
          break;
        case 'document':
          if ('document' in ctx.message && ctx.message.document) {
            const document = ctx.message.document;
            fileId = document.file_id;
            caption = 'caption' in ctx.message ? ctx.message.caption : undefined;
          }
          break;
        case 'audio':
          if ('audio' in ctx.message && ctx.message.audio) {
            const audio = ctx.message.audio;
            fileId = audio.file_id;
            caption = 'caption' in ctx.message ? ctx.message.caption : undefined;
          }
          break;
        case 'voice':
          if ('voice' in ctx.message && ctx.message.voice) {
            const voice = ctx.message.voice;
            fileId = voice.file_id;
            caption = 'caption' in ctx.message ? ctx.message.caption : undefined;
          }
          break;
      }
    }

    if (fileId) {
      // 确保caption不为空字符串
      const cleanCaption = caption && caption.trim().length > 0 ? caption.trim() : undefined;
      
      session.pendingMedia.push({
        file_id: fileId,
        file_type: mediaType,
        caption: cleanCaption
      });

      userSessions.set(userId, session);
      await db.saveUserSession(userId, session);

      // 清除之前的延迟
      const existingTimeout = this.uploadTimeouts.get(userId);
      if (existingTimeout) {
        clearTimeout(existingTimeout);
      }

      // 设置5秒延迟，确保所有媒体都收集完毕
      const timeout = setTimeout(async () => {
        const currentSession = userSessions.get(userId);
        if (!currentSession || currentSession.mode !== 'upload' || !currentSession.pendingMedia) return;

        console.log(`📋 媒体收集完成 - 用户: ${userId}, 总数: ${currentSession.pendingMedia.length}`);
        
        // 打印每个媒体的信息用于调试
        currentSession.pendingMedia.forEach((media, index) => {
          console.log(`📎 媒体 ${index + 1}: 类型=${media.file_type}, caption="${media.caption || '无'}"`);
        });

        // 统计有文字说明的媒体数量
        const mediaWithCaption = currentSession.pendingMedia.filter(media => media.caption && media.caption.trim().length > 0);
        const captionInfo = mediaWithCaption.length > 0 ? `\n📝 其中 ${mediaWithCaption.length} 个包含文字说明` : '';

        const messageText = `📤 上传模式\n\n` +
          `关键词: "${currentSession.currentKeyword}"\n` +
          `已接收 ${currentSession.pendingMedia.length} 个文件${captionInfo}\n\n` +
          `请选择目标频道：`;

        // 如果是第一个文件，发送消息；否则编辑现有消息
        if (currentSession.pendingMedia.length === 1) {
          await ctx.reply(messageText, { 
            reply_markup: { 
              inline_keyboard: [
                [{ text: '📢 选择频道', callback_data: 'select_channel' }]
              ] 
            } 
          });
        } else {
          // 编辑最后一条消息
          try {
            await ctx.editMessageText(messageText, { 
              reply_markup: { 
                inline_keyboard: [
                  [{ text: '📢 选择频道', callback_data: 'select_channel' }]
                ] 
              } 
            });
          } catch (error) {
            // 如果编辑失败，发送新消息
            await ctx.reply(messageText, { 
              reply_markup: { 
                inline_keyboard: [
                  [{ text: '📢 选择频道', callback_data: 'select_channel' }]
                ] 
              } 
            });
          }
        }

        this.uploadTimeouts.delete(userId);
      }, 15000); // 15秒延迟，确保收集完整

      this.uploadTimeouts.set(userId, timeout);
    }
  }

  static async handleChannelSelection(
    ctx: Context, 
    userSessions: Map<number, UserSession>,
    bot: Telegraf
  ): Promise<void> {
    const userId = ctx.from?.id;
    if (!userId) return;

    const session = userSessions.get(userId);
    if (!session || session.mode !== 'upload' || !session.pendingMedia || session.pendingMedia.length === 0) {
      return;
    }

    session.step = 'confirming';
    userSessions.set(userId, session);

    const channelButtons = await Promise.all(
      config.channelIds.map(async channelId => 
        [{ text: await this.getChannelFullName(bot, channelId), callback_data: `upload_channel_${channelId}` }]
      )
    );
    channelButtons.push([{ text: '💾 仅保存到数据库', callback_data: 'save_only' }]);

    await ctx.reply(
      `📤 上传确认\n\n` +
      `关键词: "${session.currentKeyword}"\n` +
      `媒体文件: ${session.pendingMedia.length} 个\n\n` +
      `请选择操作：`,
      { reply_markup: { inline_keyboard: channelButtons } }
    );
  }

  static async handleSaveOnly(
    ctx: Context, 
    userSessions: Map<number, UserSession>, 
    db: typeof database
  ): Promise<void> {
    const userId = ctx.from?.id;
    if (!userId) return;

    const session = userSessions.get(userId);
    if (!session || session.mode !== 'upload' || !session.pendingMedia || !session.currentKeyword) {
      return;
    }

    try {
      // 显示处理中消息
      const processingMsg = await ctx.reply('💾 正在保存到数据库...');

      let savedCount = 0;
      for (const media of session.pendingMedia) {
        // 合并媒体caption和用户文本描述
        let finalCaption = media.caption || '';
        if (session.pendingText && session.pendingText.trim()) {
          if (finalCaption) {
            finalCaption += '\n\n' + session.pendingText.trim();
          } else {
            finalCaption = session.pendingText.trim();
          }
        }

        console.log(`💾 保存媒体: 类型=${media.file_type}, 原始caption="${media.caption || '无'}", 用户文本="${session.pendingText || '无'}", 最终caption="${finalCaption}"`);

        const mediaItem: Omit<MediaItem, 'id'> = {
          keyword: session.currentKeyword,
          file_id: media.file_id,
          file_type: media.file_type as any,
          caption: finalCaption || undefined,
          uploaded_by: userId,
          uploaded_at: new Date().toISOString(),
          is_published: false
        };

        await db.saveMedia(mediaItem);
        savedCount++;
      }

      // 清理会话
      userSessions.delete(userId);
      await db.clearUserSession(userId);

      // 编辑处理中消息为完成消息
      await ctx.telegram.editMessageText(
        ctx.chat?.id,
        processingMsg.message_id,
        undefined,
        `✅ 保存完成！\n\n` +
        `关键词: "${session.currentKeyword}"\n` +
        `已保存 ${savedCount} 个媒体文件到数据库\n\n` +
        `💡 这些文件现在可以通过搜索模式找到。`,
        { reply_markup: { inline_keyboard: [[{ text: '🏠 返回主菜单', callback_data: 'back_to_main' }]] } }
      );

    } catch (error) {
      console.error('保存媒体错误:', error);
      await ctx.reply('❌ 保存时发生错误，请稍后重试。');
    }
  }

  static async handleSaveAndPublish(
    ctx: Context, 
    userSessions: Map<number, UserSession>, 
    db: typeof database, 
    bot: Telegraf
  ): Promise<void> {
    const userId = ctx.from?.id;
    if (!userId) return;

    const session = userSessions.get(userId);
    if (!session || session.mode !== 'upload' || !session.pendingMedia || !session.currentKeyword || !session.selectedChannel) {
      return;
    }

    try {
      // 显示处理中消息
      const processingMsg = await ctx.reply('💾📢 正在保存并发布...');

      console.log(`🔄 开始处理上传 - 用户: ${userId}, 关键词: ${session.currentKeyword}, 媒体数量: ${session.pendingMedia.length}`);

      let savedCount = 0;
      const mediaIds: number[] = [];

      // 保存到数据库
      console.log('📊 开始保存到数据库...');
      for (const media of session.pendingMedia) {
        try {
        const mediaItem: Omit<MediaItem, 'id'> = {
          keyword: session.currentKeyword,
          file_id: media.file_id,
          file_type: media.file_type as any,
          caption: media.caption,
          channel_id: session.selectedChannel,
          uploaded_by: userId,
          uploaded_at: new Date().toISOString(),
          is_published: true
        };

        const id = await db.saveMedia(mediaItem);
        mediaIds.push(id);
        savedCount++;
          console.log(`✅ 已保存媒体 ${savedCount}/${session.pendingMedia.length}`);
        } catch (saveError) {
          console.error('❌ 保存单个媒体失败:', saveError);
          // 继续处理其他媒体
        }
      }

      console.log('📢 开始发布到频道...');
      // 发布到频道 - 添加超时保护
      const publishTimeout = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('发布超时')), 60000); // 60秒超时
      });

      const publishPromise = this.publishToChannel(bot, session.selectedChannel, session.pendingMedia, session.currentKeyword);
      
      await Promise.race([publishPromise, publishTimeout]);

      // 清理会话
      userSessions.delete(userId);
      await db.clearUserSession(userId);

      // 编辑处理中消息为完成消息
      await ctx.telegram.editMessageText(
        ctx.chat?.id,
        processingMsg.message_id,
        undefined,
        `✅ 保存并发布完成！\n\n` +
        `关键词: "${session.currentKeyword}"\n` +
        `频道: ${await this.getChannelName(bot, session.selectedChannel)}\n` +
        `已处理 ${savedCount} 个媒体文件\n\n` +
        `💡 文件已保存到数据库并发布到频道。`,
        { reply_markup: { inline_keyboard: [[{ text: '🏠 返回主菜单', callback_data: 'back_to_main' }]] } }
      );

    } catch (error: any) {
      console.error('保存并发布错误:', error);
      
      // 清理会话，即使出错也要清理
      try {
        userSessions.delete(userId);
        await db.clearUserSession(userId);
      } catch (cleanupError) {
        console.error('清理会话失败:', cleanupError);
      }
      
      // 提供更具体的错误信息
      let errorMessage = '❌ 发布时发生错误，请稍后重试。';
      
      if (error.message?.includes('发布超时')) {
        errorMessage = '❌ 发布超时，可能是网络问题或媒体文件过多。\n\n💡 建议：\n1. 减少一次上传的文件数量\n2. 检查网络连接\n3. 稍后重试';
      } else if (error.message?.includes('无法发布到频道')) {
        errorMessage = `❌ ${error.message}\n\n💡 请确保：\n1. 机器人已添加到频道\n2. 机器人有发布权限\n3. 频道ID正确`;
      } else if (error.response?.error_code === 429) {
        errorMessage = '❌ 发布频率过快，请稍后重试。\n\n💡 建议：减少一次上传的文件数量';
      }
      
      await ctx.reply(errorMessage, { 
        reply_markup: { 
          inline_keyboard: [
            [{ text: '🏠 返回主菜单', callback_data: 'back_to_main' }]
          ] 
        } 
      });
    }
  }

  private static async publishToChannel(
    bot: Telegraf, 
    channelId: string, 
    mediaList: any[], 
    keyword: string
  ): Promise<void> {
    try {
      // 按类型分组媒体
      const groupedMedia = this.groupMediaByType(mediaList);
      
      // 合并所有可以组合的媒体类型（照片、视频、文档、音频）
      const photoItems = groupedMedia['photo'] || [];
      const videoItems = groupedMedia['video'] || [];
      const documentItems = groupedMedia['document'] || [];
      const audioItems = groupedMedia['audio'] || [];
      
      // 将所有媒体合并到一个数组中
      const combinedMedia = [...photoItems, ...videoItems, ...documentItems, ...audioItems];
      
      // 发送合并的所有媒体（保持完整性，不切分）
      if (combinedMedia.length > 0) {
        console.log(`📸 发送所有媒体组合 - 总数: ${combinedMedia.length}`);
        
        // 详细打印每个媒体的信息
        combinedMedia.forEach((item, index) => {
          console.log(`📎 媒体 ${index + 1}: 类型=${item.file_type}, caption="${item.caption || '无'}"`);
        });
        
        // 找到主要文字说明
        let captionIndex = 0;
        let mainCaption = '';
        for (let j = 0; j < combinedMedia.length; j++) {
          if (combinedMedia[j].caption && combinedMedia[j].caption.trim()) {
            captionIndex = j;
            mainCaption = combinedMedia[j].caption;
            console.log(`📝 使用媒体 ${j + 1} 的caption作为主说明`);
            break;
          }
        }
        
        // 根据数量决定发送策略
        if (combinedMedia.length <= 10) {
          // 10个以内，作为一个完整媒体组发送
          try {
            console.log(`📤 作为单个媒体组发送 (${combinedMedia.length} 个媒体)`);
            
            const mediaGroup = combinedMedia.map((item, index) => ({
              type: item.file_type as any,
              media: item.file_id,
              caption: index === captionIndex ? mainCaption : undefined
            }));

            await bot.telegram.sendMediaGroup(channelId, mediaGroup);
            console.log(`✅ 媒体组发送成功（完整）`);
            
          } catch (error) {
            console.error('发送完整媒体组失败，降级为单个发送:', error);
            // 降级：逐个发送
            for (let i = 0; i < combinedMedia.length; i++) {
              try {
                await this.sendSingleMediaToChannel(bot, channelId, combinedMedia[i], keyword);
                console.log(`✅ 单个媒体 ${i + 1}/${combinedMedia.length} 发送成功`);
                
                // 每个媒体间隔3秒，确保顺序
                if (i < combinedMedia.length - 1) {
                  await new Promise(resolve => setTimeout(resolve, 3000));
                }
              } catch (singleError) {
                console.error(`发送单个媒体 ${i + 1} 错误:`, singleError);
              }
            }
          }
        } else {
          // 超过10个，按10个一组切分（Telegram限制）
          console.log(`📦 媒体超过10个，分${Math.ceil(combinedMedia.length / 10)}组发送`);
          
          const chunks = this.chunkArray(combinedMedia, 10);
          for (let i = 0; i < chunks.length; i++) {
            const chunk = chunks[i];
            try {
              console.log(`📤 发送媒体组 ${i + 1}/${chunks.length} (${chunk.length} 个媒体)`);
              
              const mediaGroup = chunk.map((item, index) => ({
                type: item.file_type as any,
                media: item.file_id,
                // 第一组的第一个媒体显示主说明
                caption: (i === 0 && index === captionIndex) ? mainCaption : undefined
              }));

              await bot.telegram.sendMediaGroup(channelId, mediaGroup);
              console.log(`✅ 媒体组 ${i + 1} 发送成功`);
              
              // 组间延迟5秒，确保顺序
              if (i < chunks.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 5000));
              }
            } catch (error) {
              console.error(`发送媒体组 ${i + 1} 失败:`, error);
            }
          }
        }
      }
      
      // 发送语音消息（不能放在媒体组中）
      const voiceItems = groupedMedia['voice'] || [];
      for (const item of voiceItems) {
        try {
          await this.sendSingleMediaToChannel(bot, channelId, item, keyword);
          await new Promise(resolve => setTimeout(resolve, 1000));
          } catch (error) {
          console.error('发送语音消息错误:', error);
        }
      }
      
      // 所有媒体类型已经处理完毕
      console.log('📋 所有媒体发送完成');
    } catch (error: any) {
      console.error('发布到频道错误:', error);
      
      // 如果是频道未找到或权限不足，提供更友好的错误信息
      if (error.response?.error_code === 400 && error.response?.description?.includes('chat not found')) {
        throw new Error(`无法发布到频道：机器人未添加到频道或没有发布权限。频道ID: ${channelId}`);
      } else if (error.response?.error_code === 403) {
        throw new Error(`无法发布到频道：机器人权限不足。频道ID: ${channelId}`);
      } else {
        throw new Error(`发布失败：${error.message}`);
      }
    }
  }

  private static async sendSingleMediaToChannel(bot: Telegraf, channelId: string, item: any, keyword?: string): Promise<void> {
    const caption = this.buildCaption(keyword || '', item.caption);
    
    switch (item.file_type) {
      case 'photo':
        await bot.telegram.sendPhoto(channelId, item.file_id, { caption });
        break;
      case 'video':
        await bot.telegram.sendVideo(channelId, item.file_id, { caption });
        break;
      case 'document':
        await bot.telegram.sendDocument(channelId, item.file_id, { caption });
        break;
      case 'audio':
        await bot.telegram.sendAudio(channelId, item.file_id, { caption });
        break;
      case 'voice':
        await bot.telegram.sendVoice(channelId, item.file_id, { caption });
        break;
    }
  }

  private static groupMediaByType(mediaList: any[]): { [key: string]: any[] } {
    const grouped: { [key: string]: any[] } = {};
    
    mediaList.forEach(item => {
      if (!grouped[item.file_type]) {
        grouped[item.file_type] = [];
      }
      grouped[item.file_type].push(item);
    });
    
    return grouped;
  }

  private static chunkArray<T>(array: T[], size: number): T[][] {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  private static async getChannelName(bot: Telegraf, channelId: string): Promise<string> {
    try {
      const chat = await bot.telegram.getChat(channelId);
      if ('title' in chat) {
        return chat.title;
      } else if ('first_name' in chat) {
        return chat.first_name + (chat.last_name ? ` ${chat.last_name}` : '');
      }
      return `📢 频道 ${channelId}`;
    } catch (error) {
      console.error(`获取频道名称失败 ${channelId}:`, error);
      return `📢 频道 ${channelId}`;
    }
  }

  private static async getChannelFullName(bot: Telegraf, channelId: string): Promise<string> {
    try {
      const chat = await bot.telegram.getChat(channelId);
      if ('title' in chat) {
        return `${chat.title} - 功能正常`;
      } else if ('first_name' in chat) {
        const name = chat.first_name + (chat.last_name ? ` ${chat.last_name}` : '');
        return `${name} - 功能正常`;
      }
      return `📢 频道 ${channelId}`;
    } catch (error) {
      console.error(`获取频道完整名称失败 ${channelId}:`, error);
      return `📢 频道 ${channelId}`;
    }
  }

  private static buildCaption(keyword: string, originalCaption?: string): string {
    console.log(`🔍 buildCaption调用 - keyword: "${keyword}", originalCaption: "${originalCaption}"`);
    
    // 只返回原始说明，不添加关键词标签
    const result = originalCaption || '';
    
    console.log(`📝 buildCaption结果: "${result}"`);
    return result;
  }
}
