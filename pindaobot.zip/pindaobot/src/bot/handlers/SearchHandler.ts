import { Context } from 'telegraf';
import { database } from '../../database';
import { MediaItem } from '../../types';
import { config } from '../../config';

export class SearchHandler {
  static async handleSearch(ctx: Context, keyword: string, db: typeof database): Promise<void> {
    try {
      const userId = ctx.from?.id;
      if (!userId) return;
      
      // 确定搜索范围 - 简化权限逻辑
      const isAdmin = userId === config.superAdminId;
      
      let searchUserId: number | undefined;
      if (isAdmin) {
        // 管理员可以搜索所有数据
        searchUserId = undefined;
      } else {
        // 所有非超管用户只能搜索管理员的公共资料
        searchUserId = config.superAdminId;
      }
      
      const mediaItems = await db.getMediaByKeyword(keyword, searchUserId); // 使用getMediaByKeyword返回所有媒体，无数量限制
      
      if (mediaItems.length === 0) {
        await ctx.reply(`❌ 未找到关键词 "${keyword}" 的相关媒体文件。`);
        return;
      }

      // 统计媒体信息
      const mediaWithCaption = mediaItems.filter(item => item.caption && item.caption.trim().length > 0);
      const mediaWithoutCaption = mediaItems.filter(item => !item.caption || item.caption.trim().length === 0);
      
      // 使用合并发送方式，就像上传时一样
      const groupedMedia = this.groupMediaByType(mediaItems);
      await this.sendMediaGroups(ctx, groupedMedia);

    } catch (error) {
      console.error('搜索错误:', error);
      await ctx.reply('❌ 搜索时发生错误，请稍后重试。');
    }
  }

  private static groupMediaByType(mediaItems: MediaItem[]): { [key: string]: MediaItem[] } {
    const grouped: { [key: string]: MediaItem[] } = {};
    
    mediaItems.forEach(item => {
      if (!grouped[item.file_type]) {
        grouped[item.file_type] = [];
      }
      grouped[item.file_type].push(item);
    });
    
    return grouped;
  }

  private static formatSearchResults(groupedMedia: { [key: string]: MediaItem[] }): string {
    let result = '';
    
    Object.entries(groupedMedia).forEach(([type, items]) => {
      const typeEmoji = this.getTypeEmoji(type);
      result += `${typeEmoji} ${type}: ${items.length} 个文件\n`;
    });
    
    return result;
  }

  private static formatSearchResultsOptimized(groupedMedia: { [key: string]: MediaItem[] }): string {
    let result = '';
    
    // 合并照片和视频显示
    const photoCount = groupedMedia['photo']?.length || 0;
    const videoCount = groupedMedia['video']?.length || 0;
    const documentCount = groupedMedia['document']?.length || 0;
    const audioCount = groupedMedia['audio']?.length || 0;
    const voiceCount = groupedMedia['voice']?.length || 0;
    
    if (photoCount > 0 || videoCount > 0) {
      result += `📷 照片+视频: ${photoCount + videoCount} 个文件\n`;
    }
    if (documentCount > 0) {
      result += `📄 文档: ${documentCount} 个文件\n`;
    }
    if (audioCount > 0) {
      result += `🎵 音频: ${audioCount} 个文件\n`;
    }
    if (voiceCount > 0) {
      result += `🎤 语音: ${voiceCount} 个文件\n`;
    }
    
    return result;
  }

  private static getTypeEmoji(type: string): string {
    const emojiMap: { [key: string]: string } = {
      'photo': '🖼️',
      'video': '🎥',
      'document': '📄',
      'audio': '🎵',
      'voice': '🎤'
    };
    return emojiMap[type] || '📎';
  }

  private static async sendMediaGroups(ctx: Context, groupedMedia: { [key: string]: MediaItem[] }): Promise<void> {
    // 完全按照上传时的格式：所有媒体一起发送，文字说明只显示一次
    
    // 获取所有媒体
    const allMedia = Object.values(groupedMedia).flat();
    
    if (allMedia.length === 0) return;
    
    // 找到第一个有文字说明的媒体，作为主要说明
    const mainCaptionMedia = allMedia.find(item => item.caption && item.caption.trim().length > 0);
    const mainCaption = mainCaptionMedia ? mainCaptionMedia.caption : '';
    
    console.log(`📸 搜索模式发送所有媒体 - 总数: ${allMedia.length}, 主要说明: ${mainCaption ? '有' : '无'}`);
    
    // 按类型分组
    const photoItems = allMedia.filter(item => item.file_type === 'photo');
    const videoItems = allMedia.filter(item => item.file_type === 'video');
    const documentItems = allMedia.filter(item => item.file_type === 'document');
    const audioItems = allMedia.filter(item => item.file_type === 'audio');
    const voiceItems = allMedia.filter(item => item.file_type === 'voice');
    
    // 合并可以组合的媒体类型
    const combinedMedia = [...photoItems, ...videoItems, ...documentItems, ...audioItems];
    
    if (combinedMedia.length > 0) {
      const chunks = this.chunkArray(combinedMedia, 10);
      for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i];
        
        try {
          const mediaGroup = chunk.map((item, index) => ({
            type: item.file_type as any,
            media: item.file_id,
            caption: (i === 0 && index === 0 && mainCaption) ? mainCaption : undefined
          }));

          console.log(`🔍 搜索模式发送媒体组 - ${chunk.length} 个媒体${i === 0 && mainCaption ? ' (带说明)' : ''}`);
          await ctx.replyWithMediaGroup(mediaGroup);
          
          // 组间延迟
          if (i < chunks.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 2000));
          }
        } catch (error) {
          console.error('发送媒体组错误:', error);
          // 如果媒体组发送失败，尝试单个发送
          for (const item of chunk) {
            try {
              await this.sendSingleMedia(ctx, item);
              await new Promise(resolve => setTimeout(resolve, 1000));
            } catch (singleError) {
              console.error(`发送单个媒体错误:`, singleError);
            }
          }
        }
      }
    }
    
    // 发送语音消息（不能放在媒体组中）
    for (const item of voiceItems) {
      try {
        await this.sendSingleMedia(ctx, item);
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        console.error('发送语音消息错误:', error);
      }
    }
  }

  private static async sendSingleMedia(ctx: Context, item: MediaItem): Promise<void> {
    // 只显示原始caption，不添加额外信息
    const caption = item.caption || '';
    
    console.log(`📤 尝试发送媒体: 类型=${item.file_type}, file_id=${item.file_id}, caption="${caption}"`);
    
    switch (item.file_type) {
      case 'photo':
        await ctx.replyWithPhoto(item.file_id, { caption });
        break;
      case 'video':
        await ctx.replyWithVideo(item.file_id, { caption });
        break;
      case 'document':
        await ctx.replyWithDocument(item.file_id, { caption });
        break;
      case 'audio':
        await ctx.replyWithAudio(item.file_id, { caption });
        break;
      case 'voice':
        await ctx.replyWithVoice(item.file_id, { caption });
        break;
    }
    
    console.log(`✅ 媒体发送成功: ${item.file_type}`);
  }

  private static chunkArray<T>(array: T[], size: number): T[][] {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

}
