export interface MediaItem {
  id: number;
  keyword: string;
  file_id: string;
  file_type: 'photo' | 'video' | 'document' | 'audio' | 'voice';
  caption?: string;
  channel_id?: string;
  uploaded_by: number;
  uploaded_at: string;
  is_published: boolean;
}

export interface UserSession {
  userId: number;
  mode: BotMode;
  currentKeyword?: string;
  pendingMedia?: any[];
  pendingText?: string;  // 添加文本描述字段
  selectedChannel?: string;
  step: 'idle' | 'waiting_keyword' | 'waiting_media' | 'waiting_text' | 'waiting_channel' | 'confirming' | 'selecting_channel' | 'adding_channel' | 'adding_source_channel' | 'chatting' | 'waiting_photo' | 'waiting_video' | 'waiting_document' | 'waiting_message';
}

export interface BotConfig {
  botToken: string;
  superAdminId: number;
  channelIds: string[];
  databasePath: string;
}

export enum BotMode {
  Search = 'search',
  Upload = 'upload',
  Publish = 'publish',
  Chat = 'chat',
  AddingSourceChannel = 'adding_source_channel',
  AddingTargetChannel = 'adding_target_channel',
  Broadcast = 'broadcast',
}

export interface UserPermission {
  user_id: number;
  type: PermissionType;
  granted_at: string;
}

export type PermissionType = 'free' | 'monthly' | 'quarterly' | 'lifetime';
