import { Telegraf } from 'telegraf';
import { TelegramBot } from './bot';
import { config } from './config';
import { ForwardingService } from './forwarding';

async function main() {
  try {
    console.log('🚀 启动Telegram频道管理机器人...');
    console.log(`📊 配置信息:`);
    console.log(`   - 超级管理员ID: ${config.superAdminId}`);
    console.log(`   - 频道数量: ${config.channelIds.length}`);
    console.log(`   - 数据库路径: ${config.databasePath}`);
    
    // 检查环境变量中的代理设置
    const httpProxy = process.env.HTTP_PROXY || process.env.http_proxy;
    const httpsProxy = process.env.HTTPS_PROXY || process.env.https_proxy;
    if (httpProxy || httpsProxy) {
      console.log(`🌐 检测到代理设置: HTTP=${httpProxy || '无'}, HTTPS=${httpsProxy || '无'}`);
    } else {
      console.log('🌐 未检测到代理设置');
      console.log('💡 如果网络连接有问题，可以设置环境变量:');
      console.log('   set HTTP_PROXY=http://proxy:port');
      console.log('   set HTTPS_PROXY=http://proxy:port');
    }
    
    const telegraf = new Telegraf(config.botToken);
    const forwardingService = new ForwardingService(telegraf);
    const bot = new TelegramBot(telegraf, forwardingService);

    console.log('Starting bot...');
    console.log('💡 提示: 如果bot启动超时，请检查：');
    console.log('   1. 网络连接是否正常');
    console.log('   2. 是否能访问 https://api.telegram.org');
    console.log('   3. Bot Token是否正确');
    console.log('   4. 是否使用了代理/VPN\n');
    
    try {
      await bot.start();
      console.log('Bot started. Forwarding service disabled for safety.');
    } catch (error: any) {
      console.error('\n❌ bot.start() 失败:');
      console.error('错误信息:', error?.message || error);
      if (error?.stack) {
        console.error('错误堆栈:', error.stack);
      }
      
      // 如果是超时错误，给出更详细的建议
      if (error?.message?.includes('超时')) {
        console.error('\n💡 故障排查建议:');
        console.error('   1. 检查网络连接: ping api.telegram.org');
        console.error('   2. 如果在中国大陆，可能需要配置代理');
        console.error('   3. 检查Bot Token是否正确');
        console.error('   4. 尝试在浏览器访问: https://api.telegram.org/bot<TOKEN>/getMe');
        console.error('   5. 查看防火墙设置是否阻止了连接\n');
      }
      
      throw error;
    }
    // await forwardingService.start();
    // console.log('Forwarding service started.');
    
    console.log('✅ 机器人启动成功！');
    console.log('💡 按 Ctrl+C 停止机器人');
    
  } catch (error) {
    console.error('❌ 机器人启动失败:', error);
    process.exit(1);
  }
}

// 处理未捕获的异常 - 不退出进程，只记录错误
process.on('uncaughtException', (error) => {
  console.error('⚠️ 未捕获的异常 (继续运行):', error.message);
  console.log('🔄 机器人继续运行...');
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('⚠️ 未处理的Promise拒绝 (继续运行):', reason);
  console.log('🔄 机器人继续运行...');
});

// 启动机器人
main();
